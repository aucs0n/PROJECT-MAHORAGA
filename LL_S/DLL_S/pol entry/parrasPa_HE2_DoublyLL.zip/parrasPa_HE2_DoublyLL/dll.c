/*============================================================================
 FILE        : dll.c
 AUTHOR      : Paul Andrew F. Parras
 DESCRIPTION : contains the functions that insert and remove nodes at spcecific
                coordinates
 REVISION HISTORY
 Date: 			By: 		Description:

 ============================================================================*/
#include"dll.h"


/*============================================================================
 FUNCTION    : insertFront
 DESCRIPTION : inserts a node at the front of the list
 ARGUMENTS   : struct list *L, int x
 RETURNS     : void
 ============================================================================*/
void insertFront(struct list *L, int x) {
    struct node *real = malloc(sizeof(struct node));// makes the new node(real)
    real->data = x;
    real->prev = real->next = NULL;

    if (L->head == NULL) {// check if list is empty
        L->head = L->tail = real;//set both the head and tail node to real
    } else {
        real->next = L->head;//set the real->next to the "previous" L->head
        L->head->prev = real;//set the previous to real
        L->head = real;// set the "new" head to real
    }

    L->count++;// increment the count (count = number of nodes in list)
}

/*============================================================================
 FUNCTION    : insertRear
 DESCRIPTION : inserts a node to the end/ rear of the list
 ARGUMENTS   : struct list *L, int x
 RETURNS     : void
 ============================================================================*/
void insertRear(struct list *L, int x) {
    struct node *real = malloc(sizeof(struct node));
    real->data = x;
    real->prev = real->next = NULL;

    if (L->tail == NULL) {
        L->head = L->tail = real;
    } else {
        real->prev = L->tail;//set the previous of new node(real) to your "previous" tail
        L->tail->next = real;//set your "previous" tail->next to real
        L->tail = real;//set your "new" tail to real
    }

    L->count++;
}
/*============================================================================
 FUNCTION    : insertAt
 DESCRIPTION : inserts a node at a specific position/ index in the list
 ARGUMENTS   : struct list *L, int x, int p
 RETURNS     : void
 ============================================================================*/
void insertAt(struct list *L, int x, int p) {
    if (p < 0 || p > L->count) {
        printf("Invalid position\n");
        return;
    }

    if (p == 0) {// if user wants to insert it to position 0, its the same as insertFront
        insertFront(L, x);
    } else if (p == L->count) {// if user wants to insert it to the last position, same as insertEnd
        insertRear(L, x);
    } else {
        struct node *real = malloc(sizeof(struct node));
        real->data = x;
        real->prev = real->next = NULL;
        struct node *current = L->head; //set the current node to your head

        for (int i = 0; i < p - 1; i++) {
            current = current->next;//iterrates through the list to find specific position
        }

        real->prev = current;
        real->next = current->next;
        current->next->prev = real;
        current->next = real;

        L->count++;
    }
}

/*============================================================================
 FUNCTION    : removeFront
 DESCRIPTION : removes the first node of the list
 ARGUMENTS   : struct list *L
 RETURNS     : void
 ============================================================================*/
void removeFront(struct list *L) {
    if (L->head == NULL) {// check if list is empty
        printf("List is empty\n");
        return;
    }

    struct node *temp = L->head;

    if (L->count == 1) {
        L->head = L->tail = NULL;
    } else {
        L->head = L->head->next;
        L->head->prev = NULL;
    }

    free(temp);// freeing deletes the/a node
    L->count--;// decrement the count
}

/*============================================================================
 FUNCTION    : removeRear
 DESCRIPTION : Removes the last node of the list
 ARGUMENTS   : struct list *L
 RETURNS     : void
 ============================================================================*/
void removeRear(struct list *L) {
    if (L->tail == NULL) {
        printf("List is empty\n");
        return;
    }

    struct node *temp = L->tail;

    if (L->count == 1) {
        L->head = L->tail = NULL;
    } else {
        L->tail = L->tail->prev;
        L->tail->next = NULL;
    }

    free(temp);
    L->count--;
}

/*============================================================================
 FUNCTION    : removeAt
 DESCRIPTION : removes a node at a specific point in the list
 ARGUMENTS   : struct list *L, int p
 RETURNS     : void
 ============================================================================*/
void removeAt(struct list *L, int p) {
    if (p < 0 || p >= L->count) {
        printf("Invalid position\n");
        return;
    }

    if (p == 0) {
        removeFront(L);
    } else if (p == L->count - 1) {
        removeRear(L);
    } else {
        struct node *current = L->head;

        for (int i = 0; i < p; i++) {
            current = current->next;
        }

        current->prev->next = current->next;
        current->next->prev = current->prev;

        free(current);
        L->count--;
    }
}

/*============================================================================
 FUNCTION    : printList
 DESCRIPTION : print da list
 ARGUMENTS   : struct list *L
 RETURNS     : void
 ============================================================================*/
void printList(struct list *L) {
    struct node *current = L->head;

    while (current != NULL) {
        printf("%d ", current->data);
        current = current->next;
    }
    printf("\n");
}

/*============================================================================
 FUNCTION    : printMirror
 DESCRIPTION : print da mirror of da list
 ARGUMENTS   : struct list *L
 RETURNS     : void
 ============================================================================*/
void printMirror(struct list *L) {
    struct node *current = L->tail;

    printf("Mirror:  ");
    while (current != NULL) {
        printf("%d ", current->data);
        current = current->prev;
    }
    printf("\n");
}
